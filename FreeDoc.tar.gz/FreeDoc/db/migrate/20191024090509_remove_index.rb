class RemoveIndex < ActiveRecord::Migration[5.2]
  def change

     change_table :appointments do |t|
     t.remove :doctor
     t.remove :patient
   end
  
  end
end
