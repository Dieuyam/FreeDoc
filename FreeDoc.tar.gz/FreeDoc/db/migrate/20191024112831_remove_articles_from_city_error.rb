class RemoveArticlesFromCityError < ActiveRecord::Migration[5.2]
  def change

change_table :cities do |t|
     t.remove :articles
    
  end
end
end
