# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


#User.destroy_all
#OtherModel.destroy_all


#User.create(first_name: "jean", email:"jean@jean.jean")
#User.create(first_name: "paul", email:"paul@paul.paul")
#puts "Deux utilisateurs ont été créés"


#crée 100 profile 
# 100.times do |index|
#   User.create(first_name: "Nom#{index}", email: "email#{index}@example.com")
# end

#crée 100 profils avec la gem faker
# require 'faker'
# 100.times do
#   user = User.create!(first_name: Faker::Name.first_name, email: Faker::Internet.email)
# end

=begin
Doctor.destroy_all
Patient.destroy_all
#OtherModel.destroy_all


d = Doctor.create(first_name: "Yannick", last_name: "Yamdjeu", speciality: "neurochirurgien", zip_code: "92699")
puts d.city #renvoie nil
p = Patient.create(first_name: "Cedrick", last_name: "Yamdjeu")

a = Appointment.create(doctor: d, patient: p)

my_city=City.create(name: "LA")

puts "les profils doctor et patients ont été crées et ils sont liés par un rendez-vous"
#=> je crée une instance de chaque objet






puts a.doctor
#=> on devrait obtenir en retour le docteur "d" créé plus haut. Sinon c'est qu'on a fait une erreur

puts  a.patient
# #=> on devrait obtenir en retour le patient "p" créé plus haut. Sinon c'est qu'on a fait une erreur

puts d.patients
# #=> on devrait obtenir en retour un array contenant le patient "p" créé plus haut. Sinon c'est qu'on a fait une erreur

puts  p.doctors
# #=> on devrait obtenir en retour un array contenant le doctor "d" créé plus haut. Sinon c'est qu'on a fait une erreur

=end


require 'faker'

nbcity = 2
nbdoctor = 10
nbpatient = 100
nbappointment = 200
array_speciality = ["Accident and emergency medicine","Allergology","Anaesthetics","Cardiology","Child psychiatry","Clinical biology","Clinical chemistry","Clinical microbiology","Clinical neurophysiology","Craniofacial surgery","Dermatology","Endocrinology","Family and General Medicine","Gastroenterologic surgery","Gastroenterology","General Practice","General surgery","Geriatrics","Hematology","Immunology","Infectious diseases","Internal medicine","Laboratory medicine","Nephrology","Neuropsychiatry","Neurology","Neurosurgery","Nuclear medicine","Obstetrics and gynaecology","Occupational medicine","Ophthalmology","Oral and maxillofacial surgery","Orthopaedics","Otorhinolaryngology","Paediatric surgery","Paediatrics","Pathology","Pharmacology","Physical medicine and rehabilitation","Plastic surgery","Podiatric surgery","Preventive medicine","Psychiatry","Public health","Radiation Oncology","Radiology","Respiratory medicine","Rheumatology","Stomatology","Thoracic surgery","Tropical medicine","Urology","Vascular surgery","Venereology"]
doctors = []
patients = []
cities = []
specialities = []

#Seed des villes
nbcity.times do |x|
  city = City.create(name: Faker::Address.city)
  cities << city
  puts "Seeding City nb#{x}"
end


#Seed des  Specialités
array_speciality.size.times do |x|
  speciality = Speciality.create(name: array_speciality[x])
  specialities << speciality
  puts "Seeding Speciality nb#{x}"
end



#Patient seed - Creation des patients
nbpatient.times do |x|
  patient = Patient.create(
    first_name: Faker::Name.first_name,
    last_name: Faker::Name.last_name,
    city_id: cities[rand(0..nbcity-1)].id)
    patients << patient
  puts "Seeding Patient nb#{x}"
end



#Doctor seed - Creation des docteurs
nbdoctor.times do |x|
	doctor = Doctor.create(
    first_name: Faker::Name.first_name, 
    last_name: Faker::Name.last_name,
    zip_code: Faker::Address.zip_code,
    city: cities[rand(0..nbcity-1)])
    doctors << doctor
  puts "Seeding Doctor nb#{x}"
end



#Appointment seed - Creation des appointments
t1 = Time.parse("2019-10-23 14:40:34")
t2 = Time.parse("2021-01-01 00:00:00")
nbappointment.times do |x|
  appointment = Appointment.create(
    doctor_id: doctors[rand(0..nbdoctor-1)].id,
    patient_id: patients[rand(0..nbpatient-1)].id,
    city_id: cities[rand(0..nbcity-1)].id,
    date: rand(t1..t2))
  puts "Seeding Appointment nb#{x}"
end
#creation d'une specialité par docteur
nbdoctor.times do |x|
  doc_spe = DoctorSpeciality.create(
    doctor_id: doctors[x].id,
    speciality_id: specialties[rand(1..array_speciality.size-1)].id)
  puts "Seeding a specialty to Doctor nb#{x}"
end
#ajout de specialités aleatoires
50.times do |x|
  doc_spe = DoctorSpeciality.create(
    doctor_id: doctors[rand(0..nbdoctor-1)].id,
    speciality_id: specialities[rand(1..array_speciality.size-1)].id)
  puts "Seeding an additional Ramdom specialty to a Random Doctor nb#{x}"
end

