require 'test_helper'

class DoctorSpecialityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
