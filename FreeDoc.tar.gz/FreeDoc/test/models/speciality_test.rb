require 'test_helper'

class SpecialityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
